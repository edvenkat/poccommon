angular.module("editprofileApp", [])
.run(function() {
		
	var myApp = new Framework7();
	 
	var $$ = Dom7;

	function editprofile() {
		window.location.href="index.html";
		
	}
	function index() {
		window.location.href="Edit_profile.html";
		
	}
	var mainView = myApp.addView('.view-main', {
		// Because we want to use dynamic navbar, we need to enable it for this view:
		dynamicNavbar: false
	});
	myApp.onPageInit('ip_page', function (page) {
	   var galleryTop = new Swiper('.gallery-top', {
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				spaceBetween: 10,
				autoHeight: 'true'
			});
			var galleryThumbs = new Swiper('.gallery-thumbs', {
				spaceBetween: 30,
				centeredSlides: true,
				slidesPerView: 'auto',
				touchRatio: 0.2,
				slideToClickedSlide: true
			});
			galleryTop.params.control = galleryThumbs;
			galleryThumbs.params.control = galleryTop;
	   // For dounut chart
	   // drawCddoughnutchart1('appln_rate1','doughnutChart_application_rate1','#fc7169');
		 drawCddoughnutchart('appln_rate','doughnutChart_application_rate','#fc7169');
		drawCddoughnutchart1('appln_rate1','doughnutChart_application_rate1','#fc7169');
		drawCddoughnutchart('appln_rate2','doughnutChart_application_rate2','#fc7169');
		
		// Chart JS
	  
	   /* $$(".acrdn li h2").click(function(){
		  $$(this).next().toggleClass('dispon');
		});
		*/
		
		// Page header shrink
		
		
	   
	});


	myApp.onPageInit('ncd_page', function (page) {
	 var galleryTop = new Swiper('.gallery-top', {
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				spaceBetween: 10,
				autoHeight: 'true'
			});
			var galleryThumbs = new Swiper('.gallery-thumbs', {
				spaceBetween: 30,
				centeredSlides: true,
				slidesPerView: 'auto',
				touchRatio: 0.2,
				slideToClickedSlide: true
			});
			galleryTop.params.control = galleryThumbs;
			galleryThumbs.params.control = galleryTop;
		
		
		// For chart
			drawCddoughnutchart1('appln_rate','doughnutChart_application_rate','#fc7169');
		drawCddoughnutchart('appln_rate1','doughnutChart_application_rate1','#fc7169');
		drawCddoughnutchart('appln_rate2','doughnutChart_application_rate2','#fc7169');
	});
	myApp.onPageInit('accomadation', function (page) {
		// Do something here for "about" page

	});
	myApp.onPageInit('data', function (page) {
		// Do something here for "about" page

	});
	myApp.onPageInit('add_address', function (page) {
		// Do something here for "about" page

	});
	myApp.onPageInit('search_address', function (page) {
		// Do something here for "about" page

	});
	myApp.onPageInit('search_land', function (page) {
		// Do something here for "about" page

	});

	myApp.onPageInit('search_land_save', function (page) {
		// Do something here for "about" page

	});
	myApp.onPageInit('order_prospectus', function (page) {
		// Do something here for "about" page
	});
	myApp.onPageInit('cd_page', function (page) {
		// Do something here for "about" page
	});

	myApp.onPageInit('Enq_mesg', function (page) {
		// Do something here for "about" page
	});
	myApp.onPageInit('success', function (page) {
		// Do something here for "about" page
	});
	myApp.onPageInit('success_email', function (page) {
		// Do something here for "about" page
	});

	myApp.onPageInit('contactus', function (page) {
		// Do something here for "about" page
	});
	myApp.onPageInit('start_date', function (page) {
		// Do something here for "about" page
	});
	myApp.onPageInit('Edit_profile', function (page) {
		// Do something here for "about" page
	});

		
	$$(document).on('pageInit', function (e) {
		var page = e.detail.page;
		//myApp.alert(page.name);
		/*
		if(page.name=="Edit_profile") {
			returnKey("next");
			Keyboard.hideFormAccessoryBar(true);
			//setTimeout(function(){
				$$('#f_name').focus();    
			//},1000)
			
		}*/
		
	});

	


	// current scrollposition
	function currentScroll() {
	  return $$('.page-content').scrollTop()
	};

	// onScroll do function


	function slideTitle() {
	  // calculate height of navbar
	  navheight = 200 - currentScroll();
	  $$('.profile').css('height', navheight + 'px');
	  
	  // calculate font-size
	  titlesize = 0.14 * navheight + 12.22;
	  $$('.slidingTitle').css('font-size', titlesize + 'px');
	  
	  // calculate padding
	  titlepadding1 = 0.87*navheight-28.61;
	  titlepadding2 = -0.17*navheight+34.72;
	  $$('.slidingTitle').css('padding', titlepadding1 + 'px 0px 0px '+titlepadding2+'px');
	  
	  // floating button
	  buttonvisib = 0.02*navheight-1;
	  $$('.sliding-button').css('opacity', buttonvisib);
	  
	  // different cases
	  if (navheight >= 200) {
		$$('#title').addClass('bigTitle').removeClass('smallTitle slidingTitle');
	  } else if (navheight > 56) {
		$$('#title').addClass('slidingTitle').removeClass('smallTitle bigTitle');
	  } else if (navheight < 56) {
		$$('.profile').css('height', '56px');
		$$('.sliding-button').css('height', '56px');
		$$('#title').addClass('smallTitle').removeClass('slidingTitle bigTitle');
	  };
	};




	$$('.open-index').on('click', function () {
	  myApp.popup('.popup-index');
	});


	$$('.open-qual').on('click', function () {
	  myApp.popup('.popup-qual');
	});
	$$('.cls1').on('click', function(){
		myApp.closeModal('.popup-qual');
	});
	$$('.open-subject').on('click', function () {
	  myApp.popup('.popup-subject');
	});
	$$('.cls2').on('click', function(){
		myApp.closeModal('.popup-subject');
	});
	// For University filter
	$$('.open-university').on('click', function () {
	  myApp.popup('.popup-university');
	});
	$$('.cls3').on('click', function(){
		myApp.closeModal('.popup-university');
	});

	// For Location type
	$$('.open-ltype').on('click', function () {
	  myApp.popup('.popup-ltype');
	});
	$$('.cls4').on('click', function(){
		myApp.closeModal('.popup-ltype');
	});

	//For best match
	$$('.open-best').on('click', function () {
	  myApp.popup('.popup-best');
	});
	$$('.cls5').on('click', function(){
		myApp.closeModal('.popup-best');
	});
	//For Prvious study
	$$('.open-pstudy').on('click', function () {
	  myApp.popup('.popup-pstudy');
	});
	$$('.cls6').on('click', function(){
		myApp.closeModal('.popup-pstudy');
	});
	//For Graduate salery
	$$('.open-gsalery').on('click', function () {
	  myApp.popup('.popup-gsalery');
	});
	$$('.cls7').on('click', function(){
		myApp.closeModal('.popup-gsalery');
	});

	//For How you study
	$$('.open-howstudy').on('click', function () {
	  myApp.popup('.popup-howstudy');
	});
	$$('.cls8').on('click', function(){
		myApp.closeModal('.popup-howstudy');
	});
	//For Location
	$$('.open-location').on('click', function () {
	  myApp.popup('.popup-location');
	});
	$$('.cls9').on('click', function(){
		myApp.closeModal('.popup-location');
	});
	//For Qualification tooltip
	$$('.open-qualttip').on('click', function () {
	  myApp.popup('.popup-qualttip');
	  this.addClass('flip')
	});
	$$('.cls10').on('click', function(){
		myApp.closeModal('.popup-qualttip');
	});

	//For Qualification tooltip
	$$('.open-howttip').on('click', function () {
	  myApp.popup('.popup-howttip');
	});
	$$('.cls11').on('click', function(){
		myApp.closeModal('.popup-howttip');
	});












	//For Job Prospectus
	$$('.open-job').on('click', function () {
	  myApp.popup('.popup-job');
	});
	$$('.clsjp').on('click', function(){
		myApp.closeModal('.popup-job');
	});

	//For Job Prospectus
	$$('.open-accomadation').on('click', function () {
	  myApp.popup('.popup-accomadation');
	});
	$$('.clsac').on('click', function(){
		myApp.closeModal('.popup-accomadation');
	});


	//For Terms tooltip
	$$('.open-terms').on('click', function () {
	  myApp.popup('.popup-terms');
	});
	$$('.cls11').on('click', function(){
		myApp.closeModal('.popup-terms');
	});

	//For Privacy tooltip
	$$('.open-privacy').on('click', function () {
	  myApp.popup('.popup-privacy');
	});
	$$('.cls12').on('click', function(){
		myApp.closeModal('.popup-privacy');
	});






	//Arul for Flip
	$$('.clk_im').on('click', function(){
	$(this).parents('.popup-qual').removeClass('flip-out');
	$(this).parents('.popup-qual').addClass('flip-in');
	});

	$$('.popup-qualttip .back').on('click', function(){
	$(this).parents('body').find('.popup-qual').removeClass('flip-in');
	//$(this).parents('body').find('.popup-qual').addClass('flip-out');

	});


	  //reveal
	  $$('.accordion-list').on('click', function(){
	  if($$(this).parent().hasClass('pr_bg')) {
			$$(this).parent().removeClass('pr_bg');
		} else {
			$$(this).parent().addClass('pr_bg');
		}
	});





			 //drop download
		$(document).ready(function(){

	  $("select").change(function(){
		if ($(this).val()=="") $(this).css({color: "#aaa"});
		else $(this).css({color: "#000"});
	  });
	  
	});	



})
.directive('input1', function ($timeout) {
	return {
		link: function(scope, el, attr) {
			 el.bind('touchstart focus', function(e) {
				 $$("#event").html("focus");
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				  Keyboard.hideFormAccessoryBar(true);
				  //Keyboard.hideKeyboardAccessoryBar(false);
				//}
			  });
			  el.bind('focusout', function(e) {
				  console.log("focus out")
				   $$("#event").html("focus out");
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				  Keyboard.hideFormAccessoryBar(true);
				  //Keyboard.hideKeyboardAccessoryBar(true);
				//}
			  });
			  el.bind('blur', function(e) {
				    $$("#event").html("focus leave");
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				  Keyboard.hideFormAccessoryBar(false);
				  //Keyboard.hideKeyboardAccessoryBar(true);
				//}
			  });
			  el.bind('keyup', function(e) {
				  //alert(e.which);
				   if(e.which === 13){
					   var next_id=el.parent('div').parent('li').next('li').find('input').attr('id');
					   Keyboard.hideFormAccessoryBar(false);
					  //alert(next_id);
					//  if(next_id=="searchFieldText_1") {
					//	  Keyboard.hideFormAccessoryBar(false);
						//$$('#'+next_id).trigger('touchstart');
					 // } else {
						  $$('#'+next_id).focus();
					 // }
					 // $timeout(function() {
						  //el[0].focus();
						  
						//  },0)
					  
				   }
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				 // Keyboard.hideFormAccessoryBar(true);
				  //Keyboard.hideKeyboardAccessoryBar(true);
				//}
			  });
		}
	};
})
.directive('select1', function () {
	return {
		link: function(scope, el, attr) {
			 el.bind('touchstart focus', function(e) {
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				  Keyboard.hideFormAccessoryBar(false);
				  //Keyboard.hideKeyboardAccessoryBar(false);
				//}
			  });
			  el.bind('blur', function(e) {
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				  Keyboard.hideFormAccessoryBar(true);
				  //Keyboard.hideKeyboardAccessoryBar(true);
				//}
			  });
		}
	};
})
.directive('select2', function () {
	return {
		link: function(scope, el, attr) {
			 el.bind('touchstart focus', function(e) {
				//if (window.cordova && window.cordova.plugins.Keyboard) {
				  Keyboard.hideFormAccessoryBar(false);
				  //Keyboard.hideKeyboardAccessoryBar(false);
				//}
			  });
		}
	};
})
.controller("homeCtrl", function ($scope,$timeout) {
	$scope.changedate = function() {
		Keyboard.hideFormAccessoryBar(false);		
	}
	/*$$(document).on("keyup","input", function(e){
	   // enter key code is 13
	   //alert(e.which);
	   
	   if(e.which === 13){
		  // 
		  
		  // alert("came");
		   
		   //console.log("user pressed done");
		   //console.log($(this).parent('div').parent('li').next('li').find('input'));
		   //console.log($(this).parent('div').parent('li').next('li').find('input').attr('id'));
		   var next_id=$(this).parent('div').parent('li').next('li').find('input').attr('id');
		   //alert(next_id);
		   //setTimeout(function(){
		  if(next_id=="searchFieldText_1") {
			  Keyboard.hideFormAccessoryBar(false);
			 // e.preventDefault();
			  //e.stopPropagation();
				//setTimeout(function(){
					$timeout(function(){ $$('#'+next_id).focus();} )
					//$$('#'+next_id).trigger('click');  
					 
				//},0);
			 //return false;
			 
		  } else {
			  $$('#'+next_id).focus();  
		  }
		  
		  //setTimeout(function(){
			//$$('#'+next_id).focus();  
		 // },100)
			  // alert("setTimeout");
			
			//$$('#'+next_id).trigger('focus');
		   //e.preventDefault();
		  // e.stopPropagation();
		   //},1000);
		   
		} 
	})*/
});
