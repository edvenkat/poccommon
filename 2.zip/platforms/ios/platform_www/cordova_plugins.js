cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "com.xtify.mce.sdk.MCEPlugin",
        "file": "plugins/com.xtify.mce.sdk/MCEPlugin.js",
        "pluginId": "com.xtify.mce.sdk",
        "clobbers": [
            "MCEPlugin"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.2",
    "com.xtify.mce.sdk": "3.3.1"
};
// BOTTOM OF METADATA
});